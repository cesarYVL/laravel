<template>
            <main class="main">
            <!-- Breadcrumb -->
            <ol class="breadcrumb">
                
            </ol>
            <div class="container-fluid">
                <!-- Ejemplo de tabla Listado -->
                <div class="card">
                    <div class="card-header">
                        <i class="fa fa-align-justify"></i> Ayuda
                    </div>
                    <div class="card-body">
                        <div class="form-group row">
                            <div class="col-md-6">
                                <h4>Proyecto: </h4> <p>ItVentas 1.0 - Sistema de Ventas, Compras y Almacén</p>
                                <h4>Empresa: </h4> <p>marioRC.com.mx</p>
                                <h4>Desarrollado por: </h4> 
                                <p>Mario Rodríguez.</p> </br>
                                <p>damtec.dev@gmail.com</p>
                                <h4>Web: </h4><a href="http://www.mariorc.com.mx" target="_blank"> <p>www.mariorc.com.mx</p></a>
                                
                                
                            </div>
                        </div>
                    </div>
                </div>
                <!-- Fin ejemplo de tabla Listado -->
            </div>
        </main>
</template>