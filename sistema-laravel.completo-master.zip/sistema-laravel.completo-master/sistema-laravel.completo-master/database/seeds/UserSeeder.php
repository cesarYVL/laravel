<?php

use Illuminate\Database\Seeder;
use App\User;
use App\Persona;
class UserSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        Persona::create([
            'id' => 16,
            'nombre' => 'Marcelo',
            'tipo_documento' => 'INE',
            'num_documento' => '0000',
            'direccion' => '000',
            'telefono' => '91293',
            'email' => 'marcelo@upv.edu.mx'
        ]);

        User::create([
            'id' => 16,
            'usuario' => 'Marcelo',
            'password' => bcrypt('admin'),
            'condicion' => 1,
            'idrol' => 1
        ]);
    }
}
