<?php

use Illuminate\Http\Request;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::middleware('auth:api')->get('/user', function (Request $request) {
    return $request->user();
});

Route::apiResources(['user' => 'API\UserController']);
Route::apiResources(['proyecto' => 'API\ProyectosController']);

Route::apiResources(['usuarios_proyectos' => 'API\UsuariosProyectosController']);
Route::apiResources(['Pago' => 'API\PagosController']);

Route::apiResources(['Tarea' => 'API\TareasController']);

Route::apiResources(['Abono' => 'API\AbonoController']);


Route::get('/obtenerTareas/{id}', 'API\TareasController@obtenerTareas');

Route::get('/obtenerAbonos/{id}', 'API\AbonoController@obtenerAbonos');


Route::get('profile', 'API\UserController@profile');

Route::get('findUser', 'API\UserController@search');

Route::put('profile', 'API\UserController@updateProfile');

Route::get('/obtenerClientes', 'API\UserController@obtenerClientes');
Route::get('/obtenerDesarrolladores', 'API\UserController@obtenerDesarrolladores');

Route::post('/guardarCliente', 'API\UserController@guardarCliente');
Route::post('/guardarDesarrollador', 'API\UserController@guardarDesarrollador');


Route::get('/obtenerProyecto/{id}', 'API\ProyectosController@obtenerDatosProyecto');

Route::get('/obtenerCliente/{id}', 'API\ProyectosController@obtenerClienteProyecto');
Route::get('/obtenerDesarrolladores/{id}', 'API\ProyectosController@obtenerDesarrolladoresProyecto');

Route::get('/eliminarDesarrollador/{id}', 'API\ProyectosController@eliminarDesarrolladorDeProyecto');

Route::get('/verificaSiTieneCliente/{id}', 'API\ProyectosController@verificaSiTieneCliente');




