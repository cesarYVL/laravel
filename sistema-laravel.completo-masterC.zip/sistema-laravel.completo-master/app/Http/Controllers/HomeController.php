<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Proyecto;

class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return view('home');
    }


    public function proyecto(Request $request){
        //echo $request['idProyecto'];
      
       //return Proyecto::all();
       $proyecto = Proyecto::all();
       $p = '';
      
      for( $i = 0; $i < count( $proyecto) ; $i++ ){
        //
        
        if($proyecto[$i]->id == $request['idProyecto'] ){
          $p = $proyecto[$i];
        }
        
      }
      
        
        return view('layouts.master', ['proyecto' =>  $p ]);
    }
}
