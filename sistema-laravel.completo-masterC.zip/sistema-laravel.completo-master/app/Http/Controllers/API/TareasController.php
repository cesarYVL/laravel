<?php

namespace App\Http\Controllers\API;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Tarea;

class TareasController extends Controller
{

    public function index()
    {
      return Tarea::all();
    }
  
    public function store(Request $request)
    {
      
      return Tarea::create([
        'titulo' => $request['titulo'],
        'descripcion' => $request['descripcion'],
        'estado' => $request['estado'],
        'proyecto' => $request['proyecto'],
        'usuario' => $request['usuario']
      ]);
      
    }
    public function show($id)
    {
    }
    public function update(Request $request, $id)
    {
    }
    public function destroy($id)
    {
    }
  
    public function obtenerTareas($id)
    {
      
        return Tarea::all()->where('proyecto', $id);
      
    }
}
