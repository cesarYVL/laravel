<?php

namespace App\Http\Controllers\API;

use App\Proyecto;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\usuarios_proyectos;
use Illuminate\Support\Facades\DB;
use App\Http\Controllers\API\Auth;
  
class ProyectosController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return Proyecto::all();
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        /*$this->validate($request, [
            'name' => 'required|string|max:191',
            'email' => 'required|string|email|max:191|unique:users',
            'password' => 'required|string|min:6'
        ]);*/
      
      /*  $proyectoNuevo = new Proyecto;
        $proyectoNuevo->titulo = $request['titulo'];
        $proyectoNuevo->descripcion = $request['descripcion'];
        $proyectoNuevo->presupuesto = $request['presupuesto'];
        $proyectoNuevo->fecha_inicio = $request['fecha_inicio'];
        $proyectoNuevo->fecha_fin = $request['fecha_fin'];
        $proyectoNuevo->estado = $request['estado'];
      */
         return Proyecto::create([
            'titulo' => $request['titulo'],
            'descripcion' => $request['descripcion'],
            'presupuesto' => $request['presupuesto'],
            'fecha_inicio' => $request['fecha_inicio'],
            'fecha_fin' => $request['fecha_fin'],
            'estado' => $request['estado']
        ]);
          
      /*  $proyectoNuevo->save();
      
        return usuarios_proyectos::create([
                'proyecto' => $proyectoNuevo->id,
                'usuario' => \Auth::user()->id,
                'rol' => 'productManager'

              ]);*/
        /*return ["titulo" => $request['titulo'], 
                "descripcion" => $request['descripcion']]*/
      
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $p = Proyecto::findOrFail($id);
        /*$this->validate($request, [
            'name' => 'required|string|max:191',
            'email' => 'required|string|email|max:191|unique:users,email,'.$user->id,
            'password' => 'sometimes|min:6'
        ]);*/
        $p->update($request->all());
        return ['message' => 'Informacion del proyecto '. $request['id'] . ' Actualizada'  ];
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {

        $p = Proyecto::findOrFail($id);
        // Elimina el proyecto a la chucha
        $p->delete();
        return ['mensaje' => 'Proyecto eliminado'];
    }
  
    public function obtenerDatosProyecto($id){
      
        $p = Proyecto::findOrFail($id);
      
        return $p;

    }
  
  
    public function obtenerClienteProyecto($id){
      
      //$cliente = DB::table('usuarios_proyectos')->where('usuario', $id)->where('rol', 'cliente')->first();
      
      //$c = usuarios_proyectos::all()->where('rol', 'cliente')->where('id', $id);
      //$cliente = usuarios_proyectos::all()->where('rol', 'cliente')->where('proyecto', $id);
      
      $cliente = DB::table('users')
            ->join('usuarios_proyectos', 'users.id', '=', 'usuarios_proyectos.usuario')
            ->select('users.*', 'usuarios_proyectos.proyecto', 'usuarios_proyectos.usuario', 'usuarios_proyectos.rol')
            ->where('usuarios_proyectos.rol', 'cliente')
            ->where('usuarios_proyectos.proyecto', $id)
            ->get();
      
      return $cliente;
        

    }
  
  public function obtenerDesarrolladoresProyecto($id){
    
      $desarrolladores = DB::table('users')
            ->join('usuarios_proyectos', 'users.id', '=', 'usuarios_proyectos.usuario')
            ->select('users.*', 'usuarios_proyectos.proyecto', 'usuarios_proyectos.usuario', 'usuarios_proyectos.rol')
            ->where('usuarios_proyectos.rol', 'desarrollador')
            ->where('usuarios_proyectos.proyecto', $id)
            ->get();
      
      return $desarrolladores;
  }
  
  public function eliminarDesarrolladorDeProyecto($id){

    $desarrollador = DB::table('usuarios_proyectos')->select('*')->where('usuario', $id)->where('rol', 'desarrollador')->delete();
   
     
    return $desarrollador;
    
  }
  
  public function verificaSiTieneCliente($id){
    
    $proyecto = usuarios_proyectos::all()->where('proyecto', $id)->where('rol', 'cliente');

    return $proyecto->count();
    
  }
  
  
  
}
