<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Tarea extends Model
{
    protected $fillable = [
      'id', 'titulo', 'descripcion', 'estado', 'proyecto', 'usuario'
    ];
}
