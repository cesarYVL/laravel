<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Cambio extends Model
{
    //
}
