<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class usuarios_proyectos extends Model
{
    //
  
    protected $fillable = [
        'id', 'proyecto', 'usuario', 'rol'
    ];
}
