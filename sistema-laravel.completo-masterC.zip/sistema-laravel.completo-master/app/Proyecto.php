<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Proyecto extends Model
{
    protected $fillable = [
        'titulo', 'descripcion', 'presupuesto', 'fecha_inicio', 'fecha_fin', 'estado'
    ];
}
