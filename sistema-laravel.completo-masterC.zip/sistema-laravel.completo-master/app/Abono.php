<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Abono extends Model
{
    protected $fillable = [
       'id', 'descripcion', 'total', 'proyecto'
    ];
}
