<template>
    <div class="container-fluid">
        <div class="row justify-content-center">
            <div class="col-md-12 mt-3">
                <div class="card card-default">
                    <div class="card-header"> <h2>
                                  Abono al proyecto. 
                      
                                  

                              </h2>
                              
                              </div>

                    <div class="card-body">
                      <h2>
                        Datos del proyecto
                       </h2>
                      
                       <p>  <b> Descripcion:  </b>  {{ this.proyecto.descripcion}}  </p>
                        <p>
                          <b>Presupuesto: </b> $ {{this.proyecto.presupuesto}} MX /p>
                        <p>  <b> Estado:  </b>  {{ this.proyecto.estado}}  </p>
                        <p>  <b> Fecha Inicio:  </b>  {{ this.proyecto.fecha_inicio}}  </p>
                        <p>  <b> Fecha Fin:  </b>  {{ this.proyecto.fecha_fin}}  </p>
          
                      <hr>
                      <h2>
                        Lista de Abonos
                      </h2>
                      
                      <a style="width:100%" class="btn btn-primary" @click="agregarAbonoModal()">
                                    
                          <i class="fas fa-money-check-alt fa-lg"></i> Hacer pago
                      </a> 
                       
                      <table class="table table-hover">
                          <thead>
                            <tr>
                              <th>ID </th>
                              <th>Descripcion </th>
                              <th>Total </th>

                            </tr>
                          </thead>
                          <tbody>
                            <tr v-for="abono in abonos" :key="abono.id">
                             
                              
                              
                              <td> {{ abono.id  }} </td>
                              <td> {{ abono.descripcion  }} </td>
                              <td> {{ abono.total }} </td>

                            </tr>

                          </tbody>
                        </table>
                      
                      
                    </div>
                </div>
            </div>
        </div>
      
      
      
      
      
       <!-- MODAL PARA ASOCIAR UN DESARROLLADOR A UN PROYECTO -->
        <div class="modal fade" id="agregarPagoModal" tabindex="-1" role="dialog" aria-labelledby="modalNewLabel" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered" role="document">
                <div class="modal-content">

                  <div class="modal-header">
                      <h5 class="modal-title" id="modalNewLabel">Agregar un pago a desarrollador</h5>
                      <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                      <span aria-hidden="true">&times;</span>
                      </button>
                  </div>

                  <form @submit.prevent="agregarAbono()">
                    <div class="modal-body">


                        <div class="form-group">
                            
                          
                           <div class="form-group">
                                <label>Descripcion</label>
                                <input v-model="descripcion" type="text" name="descripcion" id="descripcion"
                                    placeholder="Descripcion del abono" class="form-control" >

                            </div>
                          
                          <div class="form-group">
                                <label>Total</label>
                                <input v-model="total" type="text" name="total" id="total"
                                    placeholder="Abono total" class="form-control" >

                            </div>

                        </div>
                    </div>



                    <div class="modal-footer">
                        <button type="button" class="btn btn-danger" data-dismiss="modal">Cerrar</button>
                        <button type="submit" class="btn btn-primary">Abonar</button>
                    </div>



                </form>

                </div>
            </div>
        </div>
      
      
      
      
    </div>
</template>

<script>
    export default {
        data() {
            
            return{
                csrf: document.querySelector('meta[name="csrf-token"]').getAttribute('content'),
                
                proyecto: {},
                abonos: {},
              
                descripcion: '',
                total: ''

                
            }
        },

        methods: {
          
          
          agregarAbonoModal(){
       
              $('#agregarPagoModal').modal('show');
            
          },
          
          obtenerAbonos(){
            axios.get("api/obtenerAbonos/" + window.idProyecto).then( ({ data }) => (this.abonos = data) );
          },
          
          obtenerDatosProyecto(){
            
             axios.get("api/obtenerProyecto/" + window.idProyecto).then( ({ data }) => (this.proyecto = data) );
            
          },
          
          agregarAbono(){
            
            
                this.$Progress.start();
                
               axios.post("api/Abono", {
                 
                  descripcion: this.descripcion,
                  total: this.total,
                  idProyecto: window.idProyecto
                 
                  
                }).then( () =>{

                    Fire.$emit('traerAbonos');
                    $('#agregarPagoModal').modal('hide');
                  
                  swal.fire({
                    type: 'success',
                    title: 'Abono realizado',
                  })
                  
                    this.$Progress.finish();

                })
                .catch( () => {
                        swal.fire({
                          type: 'error',
                          title: 'No se pudo realizar el abono',
                        })
                  
                  this.$Progress.fail();
                })

          }
          
          
          

        },
      
      created() {
          this.obtenerDatosProyecto();
          this.obtenerAbonos();
        
           Fire.$on('traerAbonos', ()=> {
                this.obtenerAbonos();
                
            });
          

        }
      
    }
</script>