<template>
    <div class="container">
        <div class="row mt-2" >
          <div class="col-md-12">

            <div class="card">
              <div class="card-header">
                <h3 class="card-title">Lista de proyectos  
                      

  
                          
                </h3>

                <div class="card-tools">
                    <button class="btn btn-success" @click="newModal"> <i class="fas fa-suitcase fa-fw"></i> Agregar nuevo proyecto </button>
                </div>
              </div>
              <!-- /.card-header -->
              <div class="card-body table-responsive p-0">
                <table class="table table-hover">
                  <thead>
                    <tr>
                      <th>ID</th>
                      <th>Título</th>
                      <th>Presupuesto</th>
                      <th>Estado</th>
                      <th>Acciones</th> 
                    </tr>
                  </thead>
                  <tbody>
                    <tr v-for="proyecto in this.proyectos" :key="proyecto.id">
                      <td>{{ proyecto.id }}</td>
                      <td>{{ proyecto.titulo }}</td>
                      <td>{{ proyecto.presupuesto }} </td>
                      <td>{{ proyecto.estado }} </td>

                      <td>
                        
                        <form method="post" action="/proyecto"> 
                            <input type="hidden" name="idProyecto" :value="proyecto.id" >
                            <input type="hidden" name="_token" :value="csrf">
                            <button style="width: 100%" class="btn btn-success" type="submit">
                                <i class="fas fa-eye fa-lg " style="white"></i> VER
                            </button>
                          <br>
                        </form>
                        

                        
                        
                        <hr>
                        
                        
                        <center>
                        
                        
                        
                     

                      <a v-if="muestraSiHayCliente(proyecto.id)" @click="agregarClienteModal(proyecto.id)">
                          <i class="fas fa-user-plus fa-lg green"></i> 
                      </a>


                        
                        
                        |
                        
                        <a href="#" @click="agregarDesarrolladoresModal(proyecto.id)">
                            <i class="fas fa-users fa-lg purple"></i>
                        </a>
                        
                        |

                        <a href="#" @click="editModal(proyecto)">
                            <i class="fa fa-edit fa-lg yellow"> </i> 
                        </a>

                        |

                        <a href="#" @click="eliminarProyecto(proyecto.id)">
                            <i class="fa fa-trash fa-lg red"> </i>
                        </a>
                         </center>
                      </td>
                    </tr>

                  </tbody>
                </table>
              </div>
              <!-- /.card-body -->

            </div>
            <!-- /.card -->
            </div>
        </div>


        <!-- MODAL PARA AÑADIR Y EDITAR LOS PROYECTOS -->
        <div class="modal fade" id="modalNew" tabindex="-1" role="dialog" aria-labelledby="modalNewLabel" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered" role="document">
                <div class="modal-content">
                
                <div class="modal-header">

                    <h5 class="modal-title" v-show="!editmode" id="modalNewLabel">Agregar nuevo proyecto</h5>
                    <h5 class="modal-title" v-show="editmode" id="modalNewLabel">Actualizar proyecto</h5>

                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                    </button>
                </div>

                <form @submit.prevent="editmode ? actualizarProyecto() : crearProyecto()">

                    <div class="modal-body">

                        
                        <div class="form-group">
                            <label>Titulo</label>
                            <input v-model="form.titulo" type="text" name="titulo" id="titulo"
                                placeholder="Titulo del proyecto" class="form-control" :class="{ 'is-invalid': form.errors.has('titulo') }">
                            <has-error :form="form" field="titulo"></has-error>
                        </div>

                        <div class="form-group">
                            <label>Descripcion</label>
                            <textarea v-model="form.descripcion" name="descripcion" id="descripcion"
                                placeholder="Descripción del proyecto" 
                                class="form-control" :class="{ 'is-invalid': form.errors.has('descripcion') }">
                            </textarea>
                            <has-error :form="form" field="descripcion"></has-error>
                        </div>

                        <div class="form-group">
                            <label>Presupuesto</label>
                            <input v-model="form.presupuesto" type="text" name="presupuesto" id="presupuesto"
                                placeholder="Presupuesto del proyecto" class="form-control" :class="{ 'is-invalid': form.errors.has('presupuesto') }">
                            <has-error :form="form" field="presupuesto"></has-error>
                        </div>

                        <div class="form-group">
                            <label>Fecha Inicio</label>
                            <input v-model="form.fecha_inicio" type="text" name="fecha_inicio" id="fecha_inicio"
                                placeholder="Fecha inicio del proyecto" class="form-control" :class="{ 'is-invalid': form.errors.has('fecha_inicio') }">
                            <has-error :form="form" field="fecha_inicio"></has-error>
                        </div>

                        <div class="form-group">
                            <label>Fecha Fin</label>
                            <input v-model="form.fecha_fin" type="text" name="fecha_fin" id="fecha_fin"
                                placeholder="Fecha de finalizacion del proyecto" class="form-control" :class="{ 'is-invalid': form.errors.has('fecha_fin') }">
                            <has-error :form="form" field="fecha_fin"></has-error>
                        </div>
                      
                      
                        <div class="form-group">
                            <label>Estado</label>
                            <select v-model="form.estado" type="text" name="estado" id="estado" class="form-control" :class="{ 'is-invalid': form.errors.has('estado') }">
                              <option value="activo" selected> Activo </option>
                              <option value="pausado"> Pausado </option>
                              <option value="terminado"> Terminado </option>
                            </select>
                           
                            <has-error :form="form" field="estado"></has-error>
                        </div>

                      
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-danger" data-dismiss="modal">Cerrar</button>
                        <button v-show="editmode" type="submit" class="btn btn-warning">Actualizar</button>
                        <button v-show="!editmode" type="submit" class="btn btn-primary">Guardar</button>
                    </div>
                </form>
                
                </div>
            
            </div>
        </div>
        
        <!-- MODAL PARA ASOCIAR UN CLIENTE A UN PROYECTO -->
        <div class="modal fade" id="agregarClienteModal" tabindex="-1" role="dialog" aria-labelledby="modalNewLabel" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered" role="document">
                <div class="modal-content">
                
                  <div class="modal-header">
                      <h5 class="modal-title" id="modalNewLabel">AGREGAR CLIENTE AL PROYECTO</h5>
                      <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                      <span aria-hidden="true">&times;</span>
                      </button>
                  </div>

                  <form @submit.prevent="agregarCliente()">
                      <div class="modal-body">
                        
                        
                          <input type="hidden" name="_token" :value="csrf">

                        
                          <div class="form-group">
                              <label>Cliente</label>
                              <select v-model="idCliente"  name="cliente" id="cliente" class="form-control">
                                <option v-for="cliente in this.clientes" :key="cliente.id"  :value="cliente.id" selected> {{cliente.name}} 
  
  
                                  </option>
                                
                              </select>

                          </div>
                      </div>
                    
                      
                    
                      <div class="modal-footer">
                          <button type="button" class="btn btn-danger" data-dismiss="modal">Cerrar</button>
                          <button type="submit" class="btn btn-primary">Guardar</button>
                      </div>
                    
                    
                    
                  </form>
                
                </div>
            </div>
        </div>
      
        <!-- MODAL PARA ASOCIAR UN DESARROLLADOR A UN PROYECTO -->
        <div class="modal fade" id="agregarDesarrolladorModal" tabindex="-1" role="dialog" aria-labelledby="modalNewLabel" aria-hidden="true">
              <div class="modal-dialog modal-dialog-centered" role="document">
                  <div class="modal-content">

                    <div class="modal-header">
                        <h5 class="modal-title" id="modalNewLabel">AGREGAR DESARROLLADOR AL PROYECTO</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                        </button>
                    </div>

                    <form @submit.prevent="agregarDesarrollador()">
                      <div class="modal-body">

                        
                          <div class="form-group">
                              <label>Desarrollador</label>
                              <select v-model="idCliente"  name="desarrollador" id="desarrollador" class="form-control">
                                <option v-if="verificarSiYaesta(desarrollador.id, form.id )" v-for="desarrollador in this.desarrolladores" :key="desarrollador.id" :value="desarrollador.id" selected> 
                                  
                                  
                                       {{desarrollador.name}}
                                  
                                 
  
  
                                  </option>
                                
                              </select>
                            
                            
                              <input type="hidden" name="proyectoD" id="proyectoD" value="this.form.id"  />
                              <input type="hidden" name="rolD" id="rolD" value="desarollador"  />
                            
                          </div>
                      </div>
                    
                      
                    
                      <div class="modal-footer">
                          <button type="button" class="btn btn-danger" data-dismiss="modal">Cerrar</button>
                          <button type="submit" class="btn btn-primary">Guardar</button>
                      </div>
                    
                    
                    
                  </form>

                  </div>
              </div>
          </div>
      
      
      
      
      
    </div>
</template>

<script>
    export default {
       props: ['idUsuario'],
        data() {
            
            return{
                csrf: document.querySelector('meta[name="csrf-token"]').getAttribute('content'),
                proyectos: {},

                editmode: false,
                clientes: {},
                desarrolladores: {},
                usuarios_proyectos: {},
              
                hayCliente: '',
              
                //Campos necesrios para guardar un cliente
                idCliente: '',
                idProyecto: '',
                //Fin de los campos
            
                form: new Form({
                    id: '',
                    titulo: '',
                    descripcion: '',
                    presupuesto: '',
                    fecha_inicio: '',
                    fecha_fin: '',
                    estado: ''
                })
                
            }
        },

        methods: {


            newModal(){
                this.editmode = false;
                this.form.reset();
                $('#modalNew').modal('show');
            },
          
            agregarClienteModal(p){
                this.form.id = p;
                $('#agregarClienteModal').modal('show');
            },
          
          
            agregarDesarrolladoresModal(p){
                this.form.id = p;
                $('#agregarDesarrolladorModal').modal('show');
            },
          
          
            editModal(proyecto){
                  this.editmode = true;
                  this.form.reset();
                  this.form.clear();
                  $('#modalNew').modal('show');
                  this.form.fill(proyecto);
            },

            cargarProyectos(){
                axios.get("api/proyecto").then( ({ data }) => (this.proyectos = data) );
            },
          
          
            crearProyecto(){
                this.$Progress.start();
                
                this.form.post('api/proyecto', { idDesarrollador: this.idCliente } )
                .then( () =>{

                    Fire.$emit('traerProyectos');
                    $('#modalNew').modal('hide');
                  
                  swal.fire({
                    type: 'success',
                    title: 'Proyecto creado',
                  })
                  
                    this.$Progress.finish();

                })
                .catch( () => {
                        swal.fire({
                          type: 'error',
                          title: 'No se pudo crear el proyecto',
                        })
                  
                  this.$Progress.fail();
                })
  
            },
          
          
            eliminarProyecto(id){
                swal.fire({
                    title: '¿Estas seguro?',
                    type: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#3085d6',
                    cancelButtonColor: '#d33',
                    cancelButtonText: 'No',
                    confirmButtonText: 'Si'
                }).then((result) => {

                    //Send request to the server
                    if (result.value) {
                        this.form.delete('api/proyecto/'+id).then( ()=>{
                            

                            swal.fire(
                                'Eliminado',
                                'El proyecto ha sido eliminado.',
                                'success'
                            )

                            Fire.$emit('traerProyectos');

                        }).catch( ()=>{
                            swal.fire("Fallo", "Si hay error.", "warning");
                            this.$Progress.fail();
                        });
                    }

                })

            },
          
            actualizarProyecto(){
                this.$Progress.start();

                this.form.put('api/proyecto/'+ this.form.id )
                .then( ()=> {
                    $('#modalNew').modal('hide');
                    swal.fire(
                        'Actualizado',
                        'Informacion actualizada',
                        'success'
                    )

                    this.$Progress.finish();
                    Fire.$emit('traerProyectos');
                })
                .catch( () => {
                    this.$Progress.fail();
                });
            },
          
          
            cargarUsuarios(){
              axios.get("api/obtenerClientes").then( ({ data }) => (this.clientes = data) );
            },
          
          
            cargarDessarrolladores(){
              axios.get("api/obtenerDesarrolladores").then( ({ data }) => (this.desarrolladores = data) );
            },
          
          
            cargarUsuariosController(){
              axios.get("api/usuarios_proyectos").then( ({ data }) => {
                this.usuarios_proyectos = data
              
                window.usuarios_proyectos = data;
              });
              
            },
          
          
            agregarCliente(){

              let currentObj = this;
              axios.post("api/guardarCliente", {
                
                idProyecto: this.form.id,
                idCliente: this.idCliente
                
              }).then( function (response) {
                    currentObj.output = response.data;
                
                    swal.fire(
                        'Guardado',
                        'Informacion guardada',
                        'success'
                    )
                      
                    Fire.$emit('traerProyectos');
                    Fire.$emit('traerUsuariosProyectos');
                    $('#agregarClienteModal').modal('hide');
                  
               }).catch( () =>{
                
                  swal.fire(
                        'No guardado',
                        'Hubo error al guardar',
                        'error'
                    )
                
              } );
            
            },
          
          
            agregarDesarrollador(){
              
              
                let currentObj = this;
                axios.post("api/guardarDesarrollador", {

                  idProyecto: this.form.id,
                  idDesarrollador: this.idCliente

                }).then( function (response) {
                      currentObj.output = response.data;

                      swal.fire(
                          'Guardado',
                          'Informacion guardada',
                          'success'
                      )

                      Fire.$emit('traerProyectos');
                      Fire.$emit('traerUsuariosProyectos');
                      $('#agregarDesarrolladorModal').modal('hide');

                 }).catch( () =>{

                    swal.fire(
                          'No guardado',
                          'Hubo error al guardar',
                          'error'
                      )

                });
              
              
            },
          
          

          muestraSiHayCliente(proyecto){

            var noHayCliente = true;
            for(var i = 0; i < this.usuarios_proyectos.length; i++){
              
              if(proyecto == this.usuarios_proyectos[i].proyecto && this.usuarios_proyectos[i].rol == 'cliente'){
                noHayCliente = false;
              }
              
            }
            
            
            return noHayCliente;
            
            
          },
          
          
          verificarSiYaesta(desarrollador, proyecto){
             
           
            
            
            var noEstaEnElProyecto = true;
            for(var i = 0; i < this.usuarios_proyectos.length; i++){
              
              if( proyecto == this.usuarios_proyectos[i].proyecto && desarrollador == this.usuarios_proyectos[i].usuario ){
                noEstaEnElProyecto = false;
              }
              
            }
            
            //return noEstaEnElProyecto;
            if(desarrollador == this.idUsuario || !noEstaEnElProyecto){
              return false;
            }else{
              return true;
            }
            
            
          }
          
          
          
          
          
          
          
   

            
        },

        created() {
            this.cargarProyectos();
            this.cargarUsuarios();
            this.cargarDessarrolladores();
            this.cargarUsuariosController();

            Fire.$on('traerProyectos', ()=> {
                this.cargarProyectos();
            });
          
            Fire.$on('traerUsuariosProyectos', ()=> {
                this.cargarUsuariosController();
            })
          
          
           
          
          
          
          
        }
    }
</script>
