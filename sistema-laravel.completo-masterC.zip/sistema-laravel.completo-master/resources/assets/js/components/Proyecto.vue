<template>
    <div class="container-fluid">
        <div class="row justify-content-center">
            <div class="col-md-12 mt-3">
                <div class="card card-default">
                    <div class="card-header"> <h2>
                                  {{ this.proyecto.titulo }} 
                              </h2>
                              
                              </div>

                    <div class="card-body">
                      
                      <h2>
                          Datos del proyecto
                        </h2>
                      
                        <p>  <b> Descripcion:  </b>  {{ this.proyecto.descripcion}}  </p>
                        <p>
                          <b>Presupuesto: </b> $ {{this.proyecto.presupuesto}} MX
  </p>
                        <p>  <b> Estado:  </b>  {{ this.proyecto.estado}}  </p>
                        <p>  <b> Fecha Inicio:  </b>  {{ this.proyecto.fecha_inicio}}  </p>
                        <p>  <b> Fecha Fin:  </b>  {{ this.proyecto.fecha_fin}}  </p>
                      
                      
                        <hr>
                        <h2>
                          Datos del cliente
                        </h2>
                      
                      
                      <table class="table table-hover">
                          <thead>
                            <tr>
                              <th>Foto</th>
                              <th>Nombre</th>
                              <th>Correo</th>

                            </tr>
                          </thead>
                          <tbody>
                            <tr>
                              <td> <img v-bind:src="'/img/profile/' + clientes[0].photo" width="100px" class="img-circle elevation-2" alt="User Image"> </td>
                              
                              
                              <td>{{ this.clientes[0].name }}</td>
                              <td>{{ this.clientes[0].email }} </td>
                              

                            </tr>

                          </tbody>
                        </table>

                      
                      
                      
                      
                      <hr>
                      <h2>
                        Desarrolladores
                      </h2>
                      
                      <table class="table table-hover">
                          <thead>
                            <tr>
                              <th>Foto</th>
                              <th>Nombre</th>
                              <th>Correo</th>
                              <th>Acciones</th>

                            </tr>
                          </thead>
                          <tbody>
                            <tr v-for="desarrollador in this.desarrolladores" :key="desarrollador.id">
                              <td> <img v-bind:src="'/img/profile/' + desarrollador.photo" width="100px" class="img-circle elevation-2" alt="User Image"> </td>
                              
                              
                              <td>{{ desarrollador.name }}</td>
                              <td>{{ desarrollador.email }} </td>
                              

                              <td>


                                <a href="#" @click="eliminarDesarrollador(desarrollador.id)">
                                    <i class="fa fa-trash fa-lg red"> </i>
                                </a>

                              </td>
                            </tr>

                          </tbody>
                        </table>
                      
                      
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
    export default {
        props: ['idProyecto'],
        data() {
            
            return{
                csrf: document.querySelector('meta[name="csrf-token"]').getAttribute('content'),
                
                proyecto: {},
                clientes: {},
                desarrolladores: {},
                

                
            }
        },

        methods: {
          
          
          obtenerDatosProyecto(){
            
             axios.get("api/obtenerProyecto/" + this.idProyecto).then( ({ data }) => (this.proyecto = data) );
            
          },
          
          obtenerCliente(){
            axios.get("api/obtenerCliente/" + this.idProyecto).then( ({ data }) => (this.clientes = data) );
            
            
          },
          
          obtenerDesarrolladores(){
              axios.get("api/obtenerDesarrolladores/" + this.idProyecto).then( ({ data }) => (this.desarrolladores = data) );
          },
          
          eliminarDesarrollador(id){
            
             //axios.get("api/obtenerDesarrolladores/" + this.idProyecto).then( ({ data }) => (this.desarrolladores = data) );
            
              swal.fire({
                      title: '¿Estas seguro?',
                      type: 'warning',
                      showCancelButton: true,
                      confirmButtonColor: '#3085d6',
                      cancelButtonColor: '#d33',
                      cancelButtonText: 'No',
                      confirmButtonText: 'Si'
                  }).then((result) => {

                      //Send request to the server
                      if (result.value) {
                          axios.get('api/eliminarDesarrollador/'+id).then( ()=>{


                              swal.fire(
                                  'Eliminado',
                                  'El desarrollador ha sido eliminado.',
                                  'success'
                              )

                              Fire.$emit('refrescar');

                          }).catch( ()=>{
                              swal.fire("Fallo", "Error al borrar el desarrollador.", "warning");
                              this.$Progress.fail();
                          });
                      }

                  })

            }
          

        },
      
      created() {
            //console.log('id ' + this.idProyecto);
          this.obtenerDatosProyecto();
          this.obtenerCliente();
          this.obtenerDesarrolladores();
          
          window.idProyecto = this.idProyecto;
          
          Fire.$on('refrescar', ()=> {
                this.obtenerDesarrolladores();
            });
          
        }
      
    }
</script>