<template>
    <div class="container-fluid">
        <div class="row justify-content-center">
            <div class="col-md-12 mt-3">
                <div class="card card-default">
                  
                    <div class="card-header"> 
                      <h2> Tareas del proyecto  </h2>     
                    </div>

                    <div class="card-body">

                      <h4>
                        <b> Proyecto:         </b>  {{this.proyecto.titulo}}       <br>
                        <b> Descripcion:      </b>  {{this.proyecto.descripcion}}  <br>
                        <b> Fin del proyecto: </b>  {{this.proyecto.fecha_fin}}
                      </h4>
                      
                      <a style="width:100%" class="btn btn-primary" @click="agregarTareaModal()">
                          <i class="fas fa-plus fa-lg"></i>  Agregar tarea
                      </a>
          
                        
                      
                      <hr>
                      <h2> Lista de tareas </h2>
                      
                      <table class="table table-hover">
                          <thead>
                            <tr>
                              <th>Id</th>
                              <th>Titulo</th>
                              <th>Descripcion</th>
                              <th>Responsable</th>
                              <th>Estado</th>
                              <th>Completar</th>

                            </tr>
                          </thead>
                          <tbody>
                            <tr v-for="tarea in this.tareas" :key="tarea.id">
                              <td> {{tarea.id}} </td>
                              <td> {{tarea.titulo}} </td>
                              <td> {{tarea.descripcion}} </td>
                              
                              <td>
                                <li v-if="tarea.usuario == d.id" v-for='d in desarrolladores'>
                                    {{ d.name }}
                                </li>  
                              </td>
                              
                              <td> {{tarea.estado}} </td>
                              
                              <td>
                                
                                <a v-if="idUsuario==tarea.usuario" class="btn btn-success" @click="completarTarea(tarea.id)">
                                    <i class="fas fa-check fa-lg"></i> completar
                                </a>
                                
                                
                              </td>
                            </tr>
                          </tbody>
                        </table>
                      
                    </div>
                </div>
            </div>
        </div>
      
      
      <div class="modal fade" id="agregarTareaModal" tabindex="-1" role="dialog" aria-labelledby="modalNewLabel" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered" role="document">
                <div class="modal-content">

                  <div class="modal-header">
                      <h5 class="modal-title" id="modalNewLabel">Agregar una nueva tarea</h5>
                      <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                      <span aria-hidden="true">&times;</span>
                      </button>
                  </div>

                  <form @submit.prevent="agregarTarea()">
                    <div class="modal-body">


                        <div class="form-group">
                          
                            <div class="form-group">
                              <label>Desarrollador</label>
                              <select v-model="usuario"  name="usuario" id="usuario" class="form-control">
                                <option v-for="desarrollador in this.desarrolladores" :key="desarrollador.id" :value="desarrollador.id" selected> 
                                       {{desarrollador.name}}
                                 </option>
                              </select>
                          </div>
                          
                            <div class="form-group">
                                <label>Titulo</label>
                                <input v-model="titulo" type="text" name="titulo" id="titulo"
                                    placeholder="Titulo de la tarea" class="form-control" >

                            </div>
                          
                            <div class="form-group">
                                <label>Descripcion</label>
                                <input v-model="descripcion" type="text" name="descripcion" id="descripcion"
                                    placeholder="Descripcion de la tarea" class="form-control" >

                            </div>
                          
                          

                        </div>
                    </div>



                    <div class="modal-footer">
                        <button type="button" class="btn btn-danger" data-dismiss="modal">Cerrar</button>
                        <button type="submit" class="btn btn-primary">Agregar</button>
                    </div>
                    
                </form>

                </div>
            </div>
        </div>
    </div>

           

</template>

<script>
    export default {
        props: ['idProyecto', 'idUsuario'],
        data() {
            
            return{
                csrf: document.querySelector('meta[name="csrf-token"]').getAttribute('content'),
                
                proyecto: {},
                desarrolladores: {},
                tareas: {},
              
                titulo: '',
                descripcion: '',
                estado: 'pendiente',
                proyecto: '',
                usuario: ''
            }
        },

        methods: {

          agregarTareaModal(){
              $('#agregarTareaModal').modal('show');
          },
          
          obtenerDesarrolladores(){
              axios.get("api/obtenerDesarrolladores/" + window.idProyecto).then( ({ data }) => (this.desarrolladores = data) );
          },
          
          obtenerDatosProyecto(){
             axios.get("api/obtenerProyecto/" + window.idProyecto).then( ({ data }) => (this.proyecto = data) );
          },
          
          obtenerTareas(){
            axios.get("api/obtenerTareas/" + window.idProyecto).then( ({ data }) => (this.tareas = data) );
          },
          
          agregarTarea(){
            
               this.$Progress.start();
                
               axios.post("api/Tarea", {
                 
                 titulo: this.titulo,
                 descripcion: this.descripcion,
                 estado: this.estado,
                 proyecto: this.idProyecto,
                 usuario: this.usuario
                  
                }).then( () =>{
                  Fire.$emit('traerTareas');
                  $('#agregarTareaModal').modal('hide');
                  swal.fire({
                    type: 'success',
                    title: 'Tarea creada',
                  })
                  this.$Progress.finish();
                })
                .catch( () => {
                  swal.fire({
                    type: 'error',
                    title: 'No se pudo crear la tarea',
                  })
                  
                  this.$Progress.fail();
                })
          },
          
          
          completarTarea(tarea){
            
            
            
          }

        },
      
      created() {
          this.obtenerDatosProyecto();
          this.obtenerDesarrolladores();
          this.obtenerTareas();
           Fire.$on('traerTareas', ()=> {
                this.obtenerTareas();

            });
          
        
          

      }
      
    }
</script>
