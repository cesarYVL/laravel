<template>
    <div class="container-fluid">
        <div class="row justify-content-center">
            <div class="col-md-12 mt-3">
                <div class="card card-default">
                  
                    <div class="card-header"> 
                      <h2> Pago a los desarrolladores.  </h2>     
                    </div>

                    <div class="card-body">

                      <h4>
                        <b>Presupuesto Inicial:     </b> $ {{this.proyecto.presupuesto }} MX <br>
                        <b>Presupuesto disponible: </b>  <span style="color:red"> $ {{ this.restante }} MX </span> 
                      </h4>
          
                      <hr>
                      <h2> Desarrolladores </h2>
                      
                      <table class="table table-hover">
                          <thead>
                            <tr>
                              <th>Foto</th>
                              <th>Nombre</th>
                              <th>Correo</th>
                              <th>Historial de pagos</th>
                              <th>Acciones</th>

                            </tr>
                          </thead>
                          <tbody>
                            <tr v-for="desarrollador in this.desarrolladores" :key="desarrollador.id">
                              <td> <img v-bind:src="'/img/profile/' + desarrollador.photo" width="100px" class="img-circle elevation-2" alt="User Image"> </td>
                              
                              
                              <td>{{ desarrollador.name }}</td>
                              <td>{{ desarrollador.email }} </td>
                              
                              <td>
                                  <li v-if="p.proyecto == proyecto.id && p.usuario == desarrollador.id " v-for='p in pagos'>
                                    <b> Monto: </b> $ {{p.total}} MX <br>
                                    <b> Descripcion: </b> {{p.descripcion}} <br>
                                    <b> Fecha: </b> {{p.fecha}}
                                    <hr>
                                  </li>
                              </td>
                              
                              <td>
                                <a style="width:100%" class="btn btn-primary" @click="agregarPagoModal(desarrollador.id, desarrollador.name)">
                                    <i class="fas fa-money-check-alt fa-lg"></i> Hacer pago
                                </a>
                              </td>
                              
                            </tr>
                          </tbody>
                        </table>
                      
                    </div>

                </div>
            </div>
        </div>
      
      
      
      
      
       <!-- MODAL PARA ASOCIAR UN DESARROLLADOR A UN PROYECTO -->
        <div class="modal fade" id="agregarPagoModal" tabindex="-1" role="dialog" aria-labelledby="modalNewLabel" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered" role="document">
                <div class="modal-content">

                  <div class="modal-header">
                      <h5 class="modal-title" id="modalNewLabel">Agregar un pago a desarrollador</h5>
                      <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                      <span aria-hidden="true">&times;</span>
                      </button>
                  </div>

                  <form @submit.prevent="agregarPago()">
                    <div class="modal-body">


                        <div class="form-group">
                            <label>Desarrollador: {{this.nombreCliente}} </label>
                          

                            <div class="form-group">
                                <label>Cantidad</label>
                                <input v-model="cantidad" type="number" name="cantidad" id="cantidad"
                                    placeholder="Cantidad del pago" class="form-control" min="1" :max="this.restante">

                            </div>
                          
                          
                           <div class="form-group">
                                <label>Descripcion</label>
                                <input v-model="descripcion" type="text" name="descripcion" id="descripcion"
                                    placeholder="Descripcion del pago" class="form-control" >

                            </div>

                        </div>
                    </div>



                    <div class="modal-footer">
                        <button type="button" class="btn btn-danger" data-dismiss="modal">Cerrar</button>
                        <button type="submit" class="btn btn-primary">Pagar</button>
                    </div>



                </form>

                </div>
            </div>
        </div>
      
      
      
      
    </div>
</template>

<script>
    export default {
        props: ['idProyecto'],
        data() {
            
            return{
                csrf: document.querySelector('meta[name="csrf-token"]').getAttribute('content'),
                
                proyecto: {},
                clientes: {},
                desarrolladores: {},
                pagos: {},
                idCliente : '',
                nombreCliente: '',
                cantidad: '',
                restante: '',
              
                descripcion: '',

                
            }
        },

        methods: {
          
          
          agregarPagoModal(desarrollador, nombre){
              this.idCliente = desarrollador;
              this.nombreCliente = nombre;
              $('#agregarPagoModal').modal('show');
          },
          
          obtenerDesarrolladores(){
              axios.get("api/obtenerDesarrolladores/" + window.idProyecto).then( ({ data }) => (this.desarrolladores = data) );
          },
          
          obtenerDatosProyecto(){
            
             axios.get("api/obtenerProyecto/" + window.idProyecto).then( ({ data }) => (this.proyecto = data) );
            
          },
          
          obtenerPagos(){
            
            axios.get("api/Pago").then( ({ data }) => {
              this.pagos = data
              this.obtenerRestante();
            });
            
           
            
          },
          
          
          obtenerRestante(){
            
            this.restante = this.proyecto.presupuesto;
            for(var i = 0; i < this.pagos.length; i++){
                
                if( this.pagos[i].proyecto == this.proyecto.id ){
                   this.restante = this.restante - this.pagos[i].total;
                }
                

             }
            
          },
          
          agregarPago(){
            
            
                this.$Progress.start();
                
               axios.post("api/Pago", {
                  desarrollador: this.idCliente,
                  cantidad: this.cantidad,
                 
                  proyecto: this.proyecto.id,
                  descripcion: this.descripcion,
                 
                  
                }).then( () =>{

                    Fire.$emit('traerPagos');
                    $('#agregarPagoModal').modal('hide');
                  
                  swal.fire({
                    type: 'success',
                    title: 'Pago realizado',
                  })
                  
                    this.$Progress.finish();

                })
                .catch( () => {
                        swal.fire({
                          type: 'error',
                          title: 'No se pudo realizar el pago',
                        })
                  
                  this.$Progress.fail();
                })

          }
          
          
          

        },
      
      created() {
            //console.log('id ' + this.idProyecto);
          this.obtenerDatosProyecto();
          //this.obtenerCliente();
          this.obtenerDesarrolladores();
          this.obtenerPagos();
        
           Fire.$on('traerPagos', ()=> {
                this.obtenerPagos();
                
            });
          

        }
      
    }
</script>