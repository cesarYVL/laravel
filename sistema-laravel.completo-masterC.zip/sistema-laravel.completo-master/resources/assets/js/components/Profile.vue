<style>
.widget-user-header{
    background-position: center center;
    background-size: cover;
    height: 250px !important;
}
.widget-user .card-footer{
    padding: 0;
}
</style>


<template>
    <div class="container">
        <div class="row">
            <div class="col-md-12 mt-3">
                <div class="card card-widget widget-user">
                <!-- Add the bg color to the header using any of the bg-* classes -->
                <div class="widget-user-header text-white" style="background-image:url('./img/user-cover.jpg')">
                    <h3 class="widget-user-username">{{this.form.name}}</h3>
                    <h5 class="widget-user-desc">{{this.form.type}}</h5>
                </div>
                <div class="widget-user-image">
                    <!-- <img class="img-circle" :src="getProfilePhoto()" alt="User Avatar"> -->
                    <img class="img-circle" :src="getProfilePhoto()" alt="User Avatar">
                </div>

                </div>
            </div>

            <!-- tab -->

            <div class="col-md-12">
                <div class="card">
                    <div class="card-header p-2">
                        <ul class="nav nav-pills">
                        <li class="nav-item"><a class="nav-link active show" href="#settings" data-toggle="tab">Datos del usuario</a></li>
                        </ul>
                    </div><!-- /.card-header -->
                    <div class="card-body">
                        <div class="tab-content">
                            <!-- Setting Tab -->
                            <div class="tab-pane active show" id="settings">
                                <form class="form-horizontal">
                                <div class="form-group">
                                    <label for="inputName" class="col-sm-2 control-label">Nombre</label>

                                    <div class="col-sm-12">
                                    <input type="" v-model="form.name" class="form-control" id="inputName" placeholder="Nombre" :class="{ 'is-invalid': form.errors.has('name') }">
                                     <has-error :form="form" field="name"></has-error>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="inputEmail" class="col-sm-2 control-label">Correo</label>

                                    <div class="col-sm-12">
                                    <input type="email" v-model="form.email" class="form-control" id="inputEmail" placeholder="Correo"  :class="{ 'is-invalid': form.errors.has('email') }">
                                     <has-error :form="form" field="email"></has-error>
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label for="inputExperience" class="col-sm-2 control-label">Sobre ti</label>

                                    <div class="col-sm-12">
                                    <textarea  v-model="form.bio" class="form-control" id="inputExperience" placeholder="Cuenta algo sobre ti..." :class="{ 'is-invalid': form.errors.has('bio') }"></textarea>
                                     <has-error :form="form" field="bio"></has-error>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="photo" class="col-sm-2 control-label">Foto de perfil</label>
                                    <div class="col-sm-12">
                                       <!-- <input type="file" @change="updateProfile" name="photo" class="form-input"> -->

                                        <input type="file" @change="updateProfile" name="photo" class="form-input">
                                    </div>

                                </div>

                                <div class="form-group">
                                    <label for="password" class="col-sm-12 control-label">Contraseña (Deja en blanco si no quieres cambiarla)</label>

                                    <div class="col-sm-12">
                                    <input type="password"
                                        v-model="form.password"
                                        class="form-control"
                                        id="password"
                                        placeholder="Contraseña"
                                        :class="{ 'is-invalid': form.errors.has('password') }"
                                    >
                                     <has-error :form="form" field="password"></has-error>
                                    </div>
                                </div>

                                <div class="form-group">
                                    <div class="col-sm-offset-2 col-sm-12">
                                    <button @click.prevent="updateInfo" type="submit" class="btn btn-success"> <i class="fas fa-save"></i> Actualizar información</button>
                                    <!-- <button  type="submit" class="btn btn-success">Update</button> -->
                                    </div>
                                </div>
                                </form>
                            </div>
                        <!-- /.tab-pane -->
                        </div>
                        <!-- /.tab-content -->
                    </div><!-- /.card-body -->
                </div>
                <!-- /.nav-tabs-custom -->
          </div>
          <!-- end tabs -->
        </div>
    </div>
</template>


<script>
    export default {
        data () {
            return {

                form: new Form({
                    id: '',
                    name: '',
                    email: '',
                    password: '',
                    type: '',
                    bio: '',
                    photo: ''
                })
            }
        },
        mounted() {
            console.log('Component mounted.')
        },

        methods:{
            getProfilePhoto(){

                let photo = (this.form.photo.length > 200 ) ? this.form.photo :  "img/profile/" + this.form.photo ;
                return photo
            },

            updateInfo(){
                this.$Progress.start();
                this.form.put('api/profile')
                .then( () => {
                    this.$Progress.finish();
                    Fire.$emit('reloadData');
                })
                .catch( ()=>{
                    this.$Progress.fail();
                })
            },

            updateProfile(e){
                let file = e.target.files[0];
                var reader = new FileReader();

                if( file['size'] <  2111775 ){
                    reader.onloadend = (file) => {
                        this.form.photo = reader.result;
                    }
                    reader.readAsDataURL(file);
                }else{

                    swal({
                        type: 'error',
                        title: 'Oops...',
                        text: 'You are uploading a large file'
                    })

                }

                

            }

        },

        created() {
            axios.get('api/profile')
            .then( ({data}) => (this.form.fill(data) ));

            Fire.$on('reloadData', ()=> {
                axios.get('api/profile').then( ({data}) => (this.form.fill(data) ));
            });
        }


    }
</script>
